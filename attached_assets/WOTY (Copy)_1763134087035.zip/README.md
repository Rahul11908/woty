
  # WOTY (Copy)

  This is a code bundle for WOTY (Copy). The original project is available at https://www.figma.com/design/yCqNbor17GmUyNWO3nz5qx/WOTY--Copy-.

  ## Running the code

  Run `npm i` to install the dependencies.

  Run `npm run dev` to start the development server.
  