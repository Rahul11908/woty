import { Card } from './ui/card';
import { Building2, Star, Heart, Sparkles, Award, Crown } from 'lucide-react';

const sponsors = [
  {
    tier: 'Platinum Sponsors',
    companies: ['TechCorp Global', 'InnovateLabs', 'Future Ventures'],
    color: 'from-purple-400 to-indigo-500',
    icon: Crown
  },
  {
    tier: 'Gold Sponsors',
    companies: ['Digital Solutions Inc.', 'Creative Agency Co.', 'MediaWorks'],
    color: 'from-orange-400 to-pink-500',
    icon: Award
  },
  {
    tier: 'Silver Sponsors',
    companies: ['StartUp Hub', 'Design Studio', 'Brand Partners', 'Marketing Pros'],
    color: 'from-teal-400 to-cyan-500',
    icon: Star
  }
];

export function SponsorsView() {
  return (
    <div className="px-6 py-8">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-14 h-14 bg-white/95 backdrop-blur-xl rounded-3xl flex items-center justify-center shadow-2xl shadow-purple-900/30 border border-white/40">
            <Sparkles className="w-7 h-7 text-purple-600" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-white drop-shadow-lg mb-1">Sponsors</h1>
            <p className="text-white/90 drop-shadow">Our valued partners</p>
          </div>
        </div>
      </div>

      {/* Sponsor Tiers */}
      <div className="space-y-8">
        {sponsors.map((tier, tierIndex) => {
          const TierIcon = tier.icon;
          return (
            <div key={tierIndex}>
              <div className="flex items-center gap-3 mb-5">
                <div className={`w-10 h-10 bg-gradient-to-br ${tier.color} rounded-2xl flex items-center justify-center shadow-lg`}>
                  <TierIcon className="w-5 h-5 text-white" strokeWidth={2} />
                </div>
                <h2 className="text-white drop-shadow-lg">{tier.tier}</h2>
              </div>
              <div className="space-y-3">
                {tier.companies.map((company, companyIndex) => (
                  <Card key={companyIndex} className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 hover:shadow-pink-900/30 transition-all hover:scale-[1.01]">
                    <div className="p-5 flex items-center gap-4">
                      <div className={`w-14 h-14 bg-gradient-to-br ${tier.color} rounded-2xl flex items-center justify-center shadow-xl flex-shrink-0`}>
                        <Building2 className="w-6 h-6 text-white" strokeWidth={2} />
                      </div>
                      <div className="flex-1">
                        <h3 className="text-gray-900 mb-1">{company}</h3>
                        <p className="text-gray-500 text-sm">{tier.tier}</p>
                      </div>
                      <button className="text-purple-600 hover:text-purple-700 px-4 py-2 rounded-lg hover:bg-purple-50 transition-colors">
                        View
                      </button>
                    </div>
                  </Card>
                ))}
              </div>
            </div>
          );
        })}
      </div>

      {/* Become a Sponsor CTA */}
      <Card className="mt-8 bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-pink-900/30 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-500/10 via-orange-500/10 to-purple-500/10" />
        <div className="p-8 text-center relative">
          <div className="w-20 h-20 bg-gradient-to-br from-pink-400 via-orange-400 to-purple-500 rounded-3xl flex items-center justify-center mx-auto mb-5 shadow-2xl">
            <Heart className="w-10 h-10 text-white" strokeWidth={2} />
          </div>
          <h2 className="text-gray-900 mb-3 text-xl">Become a Sponsor</h2>
          <p className="text-gray-700 mb-6 max-w-sm mx-auto leading-relaxed">
            Support women leaders and gain visibility with our community
          </p>
          <button className="px-8 py-4 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-2xl hover:from-pink-600 hover:to-purple-700 transition-all shadow-2xl shadow-pink-500/30 inline-flex items-center gap-2">
            <Building2 className="w-5 h-5" strokeWidth={2} />
            Contact Us
          </button>
        </div>
      </Card>
    </div>
  );
}