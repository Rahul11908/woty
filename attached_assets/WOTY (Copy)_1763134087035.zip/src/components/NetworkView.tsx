import { Card } from './ui/card';
import { Users, MessageCircle, MapPin, UserPlus, Building } from 'lucide-react';

const attendees = [
  { name: 'Sarah Chen', role: 'CEO, TechVentures', avatar: '👩🏻‍💼', color: 'from-pink-400 to-rose-500', industry: 'Technology' },
  { name: 'Jessica Williams', role: 'Founder, InnovateHub', avatar: '👩🏾‍💼', color: 'from-purple-400 to-violet-500', industry: 'Innovation' },
  { name: 'Maria Garcia', role: 'VP Marketing, BrandCo', avatar: '👩🏽‍💼', color: 'from-teal-400 to-cyan-500', industry: 'Marketing' },
  { name: 'Emily Johnson', role: 'Director, Creative Studio', avatar: '👩🏼‍💼', color: 'from-orange-400 to-pink-500', industry: 'Design' },
  { name: 'Lisa Thompson', role: 'Entrepreneur', avatar: '👩🏻‍💼', color: 'from-fuchsia-400 to-pink-500', industry: 'Startup' },
  { name: 'Amanda Lee', role: 'Chief Strategy Officer', avatar: '👩🏻‍💼', color: 'from-indigo-400 to-purple-500', industry: 'Strategy' },
];

export function NetworkView() {
  return (
    <div className="px-6 py-8">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-14 h-14 bg-white/95 backdrop-blur-xl rounded-3xl flex items-center justify-center shadow-2xl shadow-teal-900/30 border border-white/40">
            <Users className="w-7 h-7 text-teal-600" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-white drop-shadow-lg mb-1">Network</h1>
            <p className="text-white/90 drop-shadow">Connect with attendees & speakers</p>
          </div>
        </div>
      </div>

      {/* Stats Cards */}
      <div className="grid grid-cols-2 gap-4 mb-8">
        <Card className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-purple-500/10 to-pink-500/10" />
          <div className="p-5 relative">
            <div className="w-10 h-10 bg-gradient-to-br from-purple-400 to-pink-500 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
              <Users className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <div className="text-gray-900 text-2xl mb-1">142</div>
            <p className="text-gray-600 text-sm">Attendees</p>
          </div>
        </Card>
        <Card className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-teal-900/20 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-teal-500/10 to-cyan-500/10" />
          <div className="p-5 relative">
            <div className="w-10 h-10 bg-gradient-to-br from-teal-400 to-cyan-500 rounded-2xl flex items-center justify-center mb-3 shadow-lg">
              <MapPin className="w-5 h-5 text-white" strokeWidth={2} />
            </div>
            <div className="text-gray-900 text-2xl mb-1">Live</div>
            <p className="text-gray-600 text-sm">In Person</p>
          </div>
        </Card>
      </div>

      {/* Attendees List */}
      <h2 className="mb-5 text-white drop-shadow-lg flex items-center gap-2">
        <UserPlus className="w-5 h-5" strokeWidth={2} />
        Featured Attendees
      </h2>
      <div className="space-y-4">
        {attendees.map((attendee, index) => (
          <Card key={index} className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 hover:shadow-pink-900/30 transition-all hover:scale-[1.01]">
            <div className="p-5">
              <div className="flex items-center gap-4 mb-4">
                <div className={`w-16 h-16 bg-gradient-to-br ${attendee.color} rounded-2xl flex items-center justify-center text-2xl shadow-xl flex-shrink-0`}>
                  {attendee.avatar}
                </div>
                <div className="flex-1">
                  <h3 className="mb-1 text-gray-900">{attendee.name}</h3>
                  <p className="text-gray-600 mb-2">{attendee.role}</p>
                  <div className="flex items-center gap-2">
                    <Building className="w-3 h-3 text-gray-500" strokeWidth={2} />
                    <span className="text-xs text-gray-500">{attendee.industry}</span>
                  </div>
                </div>
              </div>
              <button className="w-full px-4 py-3 bg-gradient-to-r from-pink-500 to-purple-600 text-white rounded-xl hover:from-pink-600 hover:to-purple-700 transition-all shadow-lg shadow-pink-500/30 flex items-center justify-center gap-2">
                <UserPlus className="w-4 h-4" strokeWidth={2} />
                Connect
              </button>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}