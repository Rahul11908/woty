import { Card } from './ui/card';
import { Award, Trophy, Sparkles, Star } from 'lucide-react';

const nominees = [
  {
    name: 'Dr. Sarah Mitchell',
    category: 'Innovation in Healthcare',
    achievement: 'Pioneering telemedicine solutions for rural communities',
    avatar: '👩🏻‍⚕️',
    color: 'from-pink-400 to-rose-500'
  },
  {
    name: 'Maya Patel',
    category: 'Social Impact',
    achievement: 'Founded non-profit serving 50,000+ families',
    avatar: '👩🏽‍💼',
    color: 'from-purple-400 to-violet-500'
  },
  {
    name: 'Jennifer Wu',
    category: 'Technology Leadership',
    achievement: 'Led AI breakthrough in climate research',
    avatar: '👩🏻‍💻',
    color: 'from-teal-400 to-cyan-500'
  },
  {
    name: 'Rachel Anderson',
    category: 'Arts & Culture',
    achievement: 'Award-winning documentary filmmaker',
    avatar: '👩🏼‍🎨',
    color: 'from-orange-400 to-pink-500'
  },
];

export function WOTYView() {
  return (
    <div className="px-6 py-8">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-14 h-14 bg-white/95 backdrop-blur-xl rounded-3xl flex items-center justify-center shadow-2xl shadow-orange-900/30 border border-white/40">
            <Trophy className="w-7 h-7 text-orange-500" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-white drop-shadow-lg mb-1">Women of the Year</h1>
            <p className="text-white/90 drop-shadow">2025 Nominees & Winners</p>
          </div>
        </div>
      </div>

      {/* Hero Card */}
      <Card className="mb-8 bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-orange-900/30 overflow-hidden relative">
        <div className="absolute inset-0 bg-gradient-to-br from-pink-500/10 via-orange-500/10 to-purple-500/10" />
        <div className="p-8 text-center relative">
          <div className="w-20 h-20 bg-gradient-to-br from-pink-400 via-orange-400 to-purple-500 rounded-3xl flex items-center justify-center mx-auto mb-5 shadow-2xl">
            <Award className="w-10 h-10 text-white" strokeWidth={2} />
          </div>
          <h2 className="text-gray-900 mb-3 text-xl">GLORY Women of the Year 2025</h2>
          <p className="text-gray-700 max-w-sm mx-auto leading-relaxed">
            Celebrating extraordinary women making a difference in their communities and industries
          </p>
        </div>
      </Card>

      {/* Nominees */}
      <h2 className="mb-5 text-white drop-shadow-lg flex items-center gap-2">
        <Star className="w-5 h-5" strokeWidth={2} />
        Nominees
      </h2>
      <div className="space-y-4">
        {nominees.map((nominee, index) => (
          <Card key={index} className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 hover:shadow-pink-900/30 transition-all">
            <div className="p-6">
              <div className="flex items-start gap-4 mb-5">
                <div className={`w-16 h-16 bg-gradient-to-br ${nominee.color} rounded-2xl flex items-center justify-center text-3xl flex-shrink-0 shadow-xl`}>
                  {nominee.avatar}
                </div>
                <div className="flex-1">
                  <h3 className="mb-3 text-gray-900">{nominee.name}</h3>
                  <div className={`inline-flex items-center gap-2 px-4 py-2 bg-gradient-to-r ${nominee.color} text-white rounded-xl shadow-lg`}>
                    <Sparkles className="w-4 h-4" strokeWidth={2} />
                    <span className="text-sm">{nominee.category}</span>
                  </div>
                </div>
              </div>
              <div className="bg-gradient-to-br from-gray-50 to-purple-50 rounded-xl p-4 border border-purple-100/50">
                <p className="text-gray-700 leading-relaxed">{nominee.achievement}</p>
              </div>
            </div>
          </Card>
        ))}
      </div>
    </div>
  );
}