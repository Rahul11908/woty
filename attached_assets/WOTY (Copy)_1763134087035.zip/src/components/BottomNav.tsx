import { Calendar, MessageCircle, Trophy, Star } from 'lucide-react';

interface BottomNavProps {
  activeTab: string;
  onTabChange: (tab: string) => void;
}

const navItems = [
  { id: 'program', label: 'Program', icon: Calendar, color: 'from-pink-500 to-purple-600' },
  { id: 'network', label: 'Network', icon: MessageCircle, color: 'from-teal-400 to-cyan-500' },
  { id: 'woty', label: 'WOTY', icon: Trophy, color: 'from-orange-400 to-pink-500' },
  { id: 'sponsors', label: 'Sponsors', icon: Star, color: 'from-purple-500 to-indigo-600' },
];

export function BottomNav({ activeTab, onTabChange }: BottomNavProps) {
  return (
    <div className="fixed bottom-0 left-0 right-0 bg-white/95 backdrop-blur-2xl border-t border-white/40 max-w-md mx-auto shadow-2xl shadow-purple-900/20 z-50">
      <nav className="flex items-center justify-around px-2 py-2 safe-area-inset-bottom">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = activeTab === item.id;
          
          return (
            <button
              key={item.id}
              onClick={() => onTabChange(item.id)}
              className="flex flex-col items-center gap-1.5 py-2 px-4 min-w-[70px] transition-all relative group"
            >
              {isActive && (
                <div className={`absolute -top-0.5 left-1/2 -translate-x-1/2 w-12 h-1 bg-gradient-to-r ${item.color} rounded-full shadow-lg`} />
              )}
              <div className={`w-11 h-11 rounded-2xl flex items-center justify-center transition-all ${
                isActive 
                  ? `bg-gradient-to-br ${item.color} shadow-xl scale-110` 
                  : 'bg-gradient-to-br from-gray-100 to-gray-200 group-hover:from-gray-200 group-hover:to-gray-300'
              }`}>
                <Icon 
                  className={`w-5 h-5 transition-colors ${
                    isActive ? 'text-white' : 'text-gray-600 group-hover:text-gray-800'
                  }`}
                  strokeWidth={2}
                />
              </div>
              <span 
                className={`text-xs transition-colors ${
                  isActive ? 'text-gray-900' : 'text-gray-600 group-hover:text-gray-900'
                }`}
              >
                {item.label}
              </span>
            </button>
          );
        })}
      </nav>
    </div>
  );
}