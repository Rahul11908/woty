import { Clock, ChevronDown, Calendar, Mic2, Users2, Wine } from 'lucide-react';
import { Card } from './ui/card';
import gloryLogo from 'figma:asset/a92df5e9d8b8add57811d51d10b68f973979488a.png';

const schedule = [
  {
    time: '6:00 pm',
    duration: '30 min',
    event: 'VIP Arrival and Welcome Cocktail',
    color: 'from-purple-400 to-violet-500',
    icon: Wine
  },
  {
    time: '6:30 pm',
    duration: '30 min',
    event: 'Live Podcast - Cinderella Stories with Special Guest Teresa Resch',
    color: 'from-pink-400 to-rose-500',
    icon: Mic2
  },
  {
    time: '7:00 pm',
    duration: '2 hrs',
    event: 'Networking and Cocktail Reception',
    color: 'from-teal-400 to-cyan-500',
    icon: Users2
  }
];

export function ProgramView() {
  return (
    <div className="px-6 py-8">
      {/* Header */}
      <div className="mb-10">
        <div className="flex items-center gap-4 mb-3">
          <div className="w-14 h-14 bg-white/95 backdrop-blur-xl rounded-3xl flex items-center justify-center shadow-2xl shadow-pink-900/30 border border-white/40">
            <Calendar className="w-7 h-7 text-pink-600" strokeWidth={2} />
          </div>
          <div>
            <h1 className="text-white drop-shadow-lg mb-1">Event Program</h1>
            <p className="text-white/90 drop-shadow">GLORY Women of the Year 2025</p>
          </div>
        </div>
      </div>

      {/* Master of Ceremonies Card */}
      <Card className="mb-8 bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 overflow-hidden relative">
        <div className="absolute top-0 right-0 w-40 h-40 bg-gradient-to-br from-pink-200/30 to-purple-200/30 rounded-full -mr-20 -mt-20 blur-2xl" />
        <div className="p-6 relative">
          <div className="flex items-center gap-2 mb-5">
            <div className="w-8 h-8 bg-gradient-to-br from-pink-500 to-purple-600 rounded-xl flex items-center justify-center shadow-lg">
              <Mic2 className="w-4 h-4 text-white" strokeWidth={2} />
            </div>
            <p className="text-gray-700">Master of Ceremonies</p>
          </div>
          
          <div className="flex items-center gap-5">
            <div className="w-20 h-20 bg-gradient-to-br from-orange-400 to-pink-500 rounded-3xl flex items-center justify-center flex-shrink-0 shadow-xl shadow-orange-500/40">
              <span className="text-white text-xl">LC</span>
            </div>
            <div>
              <h3 className="text-gray-900 mb-2">Lance Chung</h3>
              <p className="text-gray-600">Editor-in-Chief, GLORY Media</p>
            </div>
          </div>
        </div>
      </Card>

      {/* Schedule */}
      <div className="mb-8">
        <h2 className="text-white drop-shadow-lg mb-5 flex items-center gap-2">
          <Clock className="w-5 h-5" strokeWidth={2} />
          Schedule
        </h2>
        <div className="space-y-4">
          {schedule.map((item, index) => {
            const Icon = item.icon;
            return (
              <Card key={index} className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-purple-900/20 hover:shadow-pink-900/30 transition-all hover:scale-[1.02]">
                <div className="p-5">
                  <div className="flex gap-5">
                    <div className={`w-14 h-14 bg-gradient-to-br ${item.color} rounded-2xl flex items-center justify-center flex-shrink-0 shadow-xl`}>
                      <Icon className="w-6 h-6 text-white" strokeWidth={2} />
                    </div>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-2">
                        <span className="text-gray-900">{item.time}</span>
                        <span className="px-3 py-1 bg-gradient-to-r from-pink-100 to-purple-100 text-purple-700 rounded-lg text-xs">
                          {item.duration}
                        </span>
                      </div>
                      <p className="text-gray-700 leading-relaxed">{item.event}</p>
                    </div>
                  </div>
                </div>
              </Card>
            );
          })}
        </div>
      </div>

      {/* Live Podcast Section */}
      <div className="mb-6">
        <h2 className="mb-5 text-white drop-shadow-lg flex items-center gap-2">
          <Mic2 className="w-5 h-5" strokeWidth={2} />
          Live Podcast Session
        </h2>
        
        <Card className="bg-white/95 backdrop-blur-xl border border-white/40 shadow-2xl shadow-teal-900/30 overflow-hidden relative">
          <div className="absolute inset-0 bg-gradient-to-br from-pink-500/10 via-orange-500/10 to-teal-500/10" />
          <div className="p-7 relative">
            <div className="flex items-center justify-between mb-5">
              <div className="flex items-center gap-2 px-4 py-2 bg-gradient-to-r from-pink-500/20 to-purple-500/20 backdrop-blur-md text-gray-900 rounded-xl border border-pink-300/30">
                <Clock className="w-4 h-4" strokeWidth={2} />
                <span className="text-sm">6:30 pm - 7:00 pm</span>
              </div>
              <div className="px-4 py-2 bg-gradient-to-r from-red-500 to-pink-500 text-white rounded-xl text-sm shadow-lg flex items-center gap-2 animate-pulse">
                <div className="w-2 h-2 bg-white rounded-full" />
                LIVE
              </div>
            </div>
            
            <h3 className="text-gray-900 mb-5 text-xl">Cinderella Stories with Teresa Resch</h3>
            
            <p className="text-gray-700 mb-6 leading-relaxed">
              Join GLORY Media for a live Episode of our hit podcast Cinderella Stories, featuring Teresa Resch, Toronto Tempo President.
            </p>
            
            <div className="flex items-center gap-4 bg-gradient-to-br from-pink-100/80 to-purple-100/80 backdrop-blur-md rounded-2xl p-4 border border-pink-200/50">
              <div className="w-14 h-14 bg-gradient-to-br from-pink-400 to-purple-500 rounded-2xl overflow-hidden flex-shrink-0 shadow-lg">
                <div className="w-full h-full flex items-center justify-center">
                  <span className="text-2xl">👩🏼‍💼</span>
                </div>
              </div>
              <div>
                <p className="text-purple-700 text-sm mb-1">Special Guest</p>
                <p className="text-gray-900">Teresa Resch</p>
                <p className="text-gray-600 text-sm">Toronto Tempo President</p>
              </div>
            </div>
          </div>
        </Card>
      </div>
    </div>
  );
}