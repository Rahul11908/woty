import { useState } from 'react';
import { ProgramView } from './components/ProgramView';
import { NetworkView } from './components/NetworkView';
import { WOTYView } from './components/WOTYView';
import { SponsorsView } from './components/SponsorsView';
import { BottomNav } from './components/BottomNav';
import brandImage from 'figma:asset/a92df5e9d8b8add57811d51d10b68f973979488a.png';

export default function App() {
  const [activeTab, setActiveTab] = useState('program');

  return (
    <div className="h-screen relative flex flex-col max-w-md mx-auto overflow-hidden">
      {/* Animated Background Gradient - matching GLORY brand */}
      <div className="absolute inset-0 bg-gradient-to-br from-pink-500 via-orange-400 to-teal-600 opacity-95" />
      <div className="absolute inset-0 bg-gradient-to-tr from-purple-600 via-transparent to-transparent opacity-70" />
      <div className="absolute inset-0 bg-gradient-to-bl from-transparent via-teal-700 to-purple-700 opacity-60" />
      
      {/* Texture overlay */}
      <div className="absolute inset-0 opacity-[0.15]" style={{
        backgroundImage: 'url("data:image/svg+xml,%3Csvg viewBox="0 0 400 400" xmlns="http://www.w3.org/2000/svg"%3E%3Cfilter id="noiseFilter"%3E%3CfeTurbulence type="fractalNoise" baseFrequency="2" numOctaves="3" /%3E%3C/filter%3E%3Crect width="100%25" height="100%25" filter="url(%23noiseFilter)" /%3E%3C/svg%3E")',
      }} />
      
      {/* Main Content */}
      <div className="flex-1 overflow-auto pb-24 relative z-10">
        {activeTab === 'program' && <ProgramView />}
        {activeTab === 'network' && <NetworkView />}
        {activeTab === 'woty' && <WOTYView />}
        {activeTab === 'sponsors' && <SponsorsView />}
      </div>

      {/* Bottom Navigation */}
      <BottomNav activeTab={activeTab} onTabChange={setActiveTab} />
    </div>
  );
}